package tw.com.mathison.quizs;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import tw.com.mathison.quizs.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private ActivityMainBinding binding;

//    private TextView questionView;
//    private Button buttonTrue;
//    private Button buttonFalse;
//    private Button buttonNext;
    private int currentIndex;


    Question question;

    private Question[] questionBank = new Question[]{
            new Question(R.string.question_1, true),
            new Question(R.string.question_2, false),
            new Question(R.string.question_3, true)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
//        Log.d("Main", "onCreate: " + questionBank[0]);
//        questionView = findViewById(R.id.text_question);
//        questionView = binding.textQuestion;
//        buttonTrue = findViewById(R.id.button_true);
//        buttonFalse = findViewById(R.id.button_false);
//        buttonNext = findViewById(R.id.button_next);

        question = questionBank[currentIndex];
        question.setTitle(getString(question.getResId()));
//        binding.textQuestion.setText(question.getResId());
        binding.setQuestion(question);

        binding.buttonTrue.setOnClickListener(this);

        binding.buttonFalse.setOnClickListener(this);

        binding.buttonNext.setOnClickListener(this);
    }

    private void checkAnswer(boolean answer) {
        if (questionBank[currentIndex].isAnswerTrue() == answer){
            Log.d("answer", "checkAnswer: " + answer + " real: " + question.isAnswerTrue());
            Toast.makeText(MainActivity.this,
                    "Your answer is right!",
                    Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(MainActivity.this,
                    "Your answer is wrong!",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.button_true:
                checkAnswer(true);
                break;
            case R.id.button_false:
                checkAnswer(false);
                break;
            case R.id.button_next:
                currentIndex = (currentIndex + 1) % questionBank.length;
                String title = getString(questionBank[currentIndex].getResId());
                questionBank[currentIndex].setTitle(title);
                binding.setQuestion(questionBank[currentIndex]);
//                binding.textQuestion.setText();

        }
    }

//    public void onClickMethod(View view) {
//        switch(view.getId()){
//            case R.id.button_true:
//                extracted(true);
//                break;
//            case R.id.button_false:
//                extracted(false);
//                break;
//        }
//
//    }
}