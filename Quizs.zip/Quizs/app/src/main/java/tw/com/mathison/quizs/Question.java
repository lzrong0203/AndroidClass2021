package tw.com.mathison.quizs;

public class Question {

    private int resId;
    private Boolean answerTrue;
    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Question() {
    }

    public Question(int resId, Boolean answerTrue) {
        this.resId = resId;
        this.answerTrue = answerTrue;
    }

    public int getResId() {
        return resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }

    public Boolean isAnswerTrue() {
        return answerTrue;
    }

    public void setAnswer(Boolean answerTrue) {
        this.answerTrue = answerTrue;
    }

    @Override
    public String toString() {
        return "Question{" +
                "resId=" + resId +
                ", answerTrue=" + answerTrue +
                '}';
    }
}
