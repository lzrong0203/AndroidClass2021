package tw.com.mathison.animaladoption;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;

import tw.com.mathison.animaladoption.data.MySingleton;
import tw.com.mathison.animaladoption.data.Repository;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "AnimalJSON";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new Repository(getApplicationContext()).getAnimalList();
    }
}