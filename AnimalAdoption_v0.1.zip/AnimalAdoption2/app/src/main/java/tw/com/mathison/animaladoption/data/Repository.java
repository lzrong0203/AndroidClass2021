package tw.com.mathison.animaladoption.data;

import android.content.Context;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;

import java.util.ArrayList;
import java.util.List;

import tw.com.mathison.animaladoption.model.Animal;

public class Repository {

    private static final String TAG = "Repository";
    private List<Animal> animalList;
    private Context ctx;

    public Repository(Context ctx) {
        animalList = new ArrayList<>();
        this.ctx = ctx;
    }

    public List<Animal> getAnimalList(){

        String url = "https://data.coa.gov.tw/Service/OpenData/TransService.aspx?UnitId=QcbUEzN6E6DL";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET
                , url, null, response -> {
            Log.d(TAG, "onCreate: " + response);
        }, error -> {
            Log.d(TAG, "onCreate: " + error);
        });

        MySingleton.getInstance(ctx.getApplicationContext()).addToRequestQueue(jsonArrayRequest);
        return null;
    }

}
