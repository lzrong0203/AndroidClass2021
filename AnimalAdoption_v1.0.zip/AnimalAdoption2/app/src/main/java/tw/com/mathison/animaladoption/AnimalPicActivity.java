package tw.com.mathison.animaladoption;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.ImageRequest;

import tw.com.mathison.animaladoption.controller.MySingleton;

public class AnimalPicActivity extends AppCompatActivity {

    private static final String TAG = "Pictures";
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal_pic);
        Intent intent = getIntent();
        String imageUrl = intent.getStringExtra("ImageUrl");
        Log.d(TAG, "onCreate: " + imageUrl);
        imageView = findViewById(R.id.imageView);


        ImageRequest request = new ImageRequest(imageUrl,
                new Response.Listener<Bitmap>() {
                    @Override
                    public void onResponse(Bitmap bitmap) {
                        imageView.setImageBitmap(bitmap);
                    }
                }, 0, 0, ImageView.ScaleType.FIT_CENTER,null,
                new Response.ErrorListener() {
                    public void onErrorResponse(VolleyError error) {
//                        mImageView.setImageResource(R.drawable.image_load_error);
                    }
                });
        // Access the RequestQueue through your singleton class.
        MySingleton.getInstance(this).addToRequestQueue(request);
    }
}