package tw.com.mathison.animaladoption;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import java.util.List;

import tw.com.mathison.animaladoption.data.AnimalListAsyncListener;
import tw.com.mathison.animaladoption.data.Repository;
import tw.com.mathison.animaladoption.databinding.ActivityMainBinding;
import tw.com.mathison.animaladoption.model.Animal;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "AnimalJSON";
    private List<Animal> animalList;
    private ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        animalList = new Repository(getApplicationContext()).getAnimalList(new AnimalListAsyncListener() {
            @Override
            public void fetchFinished(List<Animal> animalList) {
                ArrayAdapter<Animal> arrayAdapter = new ArrayAdapter<>(MainActivity.this,
                        android.R.layout.simple_list_item_1,
                        animalList);
                binding.listView.setAdapter(arrayAdapter);
            }
        });

        binding.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long l) {
                Log.d(TAG, "onItemClick: " + animalList.get(pos));
                Intent intent = new Intent(MainActivity.this, AnimalPicActivity.class);
                intent.putExtra("ImageUrl", animalList.get(pos).getAlbumFile());
                startActivity(intent);
            }
        });

    }


}