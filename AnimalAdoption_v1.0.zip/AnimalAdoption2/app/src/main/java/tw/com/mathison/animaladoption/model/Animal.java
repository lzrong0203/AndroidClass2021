package tw.com.mathison.animaladoption.model;

public class Animal {

    private String place;
    private String kind;
    private String albumFile;

    public Animal() {}

    public Animal(String place, String kind, String albumFile) {
        this.place = place;
        this.kind = kind;
        this.albumFile = albumFile;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getAlbumFile() {
        return albumFile;
    }

    public void setAlbumFile(String albumFile) {
        this.albumFile = albumFile;
    }

    @Override
    public String toString() {
        return String.format("地點： %s, 種類： %s", place, kind);
    }
}
