package tw.com.mathison.animaladoption.data;

import java.util.List;

import tw.com.mathison.animaladoption.model.Animal;

public interface AnimalListAsyncListener {
    void fetchFinished(List<Animal> animalList);
}
